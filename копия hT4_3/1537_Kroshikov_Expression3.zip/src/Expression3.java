public interface Expression3 {
    public double evaluate(double var1, double var2, double var3);
}
